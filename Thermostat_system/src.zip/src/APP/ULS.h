#ifndef ULTRASONIC_H
#define ULTRASONIC_H

void Ultrasonic_Init(void);
float Ultrasonic_ReadDistanceCM(void);

#endif
