#ifndef POT_H
#define POT_H

void POT_init(void);
void POT_main(void);

uint16_t POT_value_Getter(void);

#endif
