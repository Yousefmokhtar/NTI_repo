#ifndef LM35_H
#define LM35_H

void LM35_Init(void);
float LM35_ReadTempC(void);
float LM35_ReadTempF(void);

#endif
